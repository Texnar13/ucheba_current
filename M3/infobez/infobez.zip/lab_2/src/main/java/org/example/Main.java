package org.example;

import javax.swing.*; // подключаем все средства java Swing
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello and welcome!");



        //
//
//        JFrame frame = new JFrame("My First GUI"); // Для окна нужна "рама" - Frame
//        // стандартное поведение при закрытии окна - завершение приложения
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(300, 300); // размеры окна
//        frame.setLocationRelativeTo(null); // окно - в центре экрана
//        JButton button = new JButton("Press"); // Экземпляр класса JButton
//        // getContentPane() - клиентская область окна
//        frame.getContentPane().add(button); // Добавляем кнопку на Frame
//        frame.setVisible(true); // Делаем окно видимым
//
//        button.addActionListener(actionEvent -> {
//            JFrame frame2 = new JFrame("My First GUI"); // Для окна нужна "рама" - Frame
//            frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame2.setSize(300, 300); // размеры окна
//            frame2.setLocationRelativeTo(button); // окно - в центре экрана
//            frame2.setVisible(true); // Делаем окно видимым
//
//
//            JTextArea text = new JTextArea(frame2);
//        });

    }
}